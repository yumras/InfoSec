define(['jquery',
	'underscore',
	'backbone'], function($,_,Backbone) {

	return Backbone.View.extend({
		initialize: function(options) {
			options = options || {};

		}


	});

});