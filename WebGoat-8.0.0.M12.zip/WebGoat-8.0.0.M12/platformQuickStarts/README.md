# OWASP WebGoat Platform Quick Starts

Want to Run WebGoat? Want to run WebGoat in the Cloud? Don't want to be cloud Expert?

Do we have a solution for you!


Additionally, Each IaaS/PaaS will have their deployment steps broken down giving the *app-guy-new-to-cloud* an opportunity to learn how said platform works.



## AWS

Multi-Part Quickstart. Starts with simple pipeline that just builds code to a deploying onto EC2 instances and then containers using ECS/ECR

## GCP

Get WebGoat Running on GKE and AppEngine




